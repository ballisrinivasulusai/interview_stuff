#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
typedef int(*FPTR)(int,int);
void main()
{
int i=10,j=20,k;
//int (*p[4])(int,int)={sum,sub,mul,dive};
FPTR p[4]={sum,sub,mul,dive};
for(k=0;k<4;k++)
printf("%d\n",(*p[k])(i,j));
}






int sum(int m,int n)
{
return m+n;
}
int sub(int m,int n)
{
return m-n;
}
int mul(int m,int n)
{
return m*n;
}
int dive(int m,int n)
{
return m/n;
}



