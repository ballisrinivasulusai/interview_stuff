#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
//int(*)(int,int)Ret_mul_fun_addr(void);
//int(*Ret_mul_fun_addr(void))(int,int);
typedef int(*FPTR)(int,int);
FPTR Ret_mul_fun_addr(void);
void main()
{
int i=10,j=20,k;
//int (*p)(int,int);
FPTR p;
p=Ret_mul_fun_addr();
k=(*p)(i,j);
printf("k=%d\n",k);
}
//int(*Ret_mul_fun_addr(void))(int,int)
FPTR Ret_mul_fun_addr(void)
{
return mul;
}





int sum(int m,int n)
{
return m+n;
}
int sub(int m,int n)
{
return m-n;
}
int mul(int m,int n)
{
return m*n;
}
int dive(int m,int n)
{
return m/n;
}



