#include<stdio.h>
int sum(int,int);
int sub(int,int);
int mul(int,int);
int dive(int,int);
//int CallBackFun(int,int,int(*)(int,int));
int CallBackFun(int,int,FPTR);
typedef int(*FPTR)(int,int);
void main()
{
int i=10,j=20,k;

k=CallBackFun(i,j,sum);
printf("k=%d\n",k);
}
//int CallBackFun(int m,int n,int(*p)(int,int))
int CallBackFun(int m,int n,FPTR p)
{
int r;
	r=(*p)(m,n);
	return r;
}





int sum(int m,int n)
{
return m+n;
}
int sub(int m,int n)
{
return m-n;
}
int mul(int m,int n)
{
return m*n;
}
int dive(int m,int n)
{
return m/n;
}



