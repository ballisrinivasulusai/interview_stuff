#include"header.h"

void main()
{

int r=mkfifo("f1",0664);
printf("r=%d\n",r);


printf("Hello\n");
int fd=open("f1",O_WRONLY);
printf("Hai...\n");
char s[10];
printf("Enter the data...\n");
scanf("%s",s);
write(fd,s,strlen(s)+1);
perror("write");


}
