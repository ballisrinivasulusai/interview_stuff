#include"header.h"

void main()
{

int r=mkfifo("f1",0664);
printf("r=%d\n",r);


printf("Hello\n");
int fd=open("f1",O_RDONLY);
printf("Hai...\n");
char s[10];
read(fd,s,sizeof(s));
printf("Data=%s\n",s);

}
