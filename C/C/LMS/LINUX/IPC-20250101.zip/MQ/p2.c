#include"header.h"
struct msgbuf 
{
long mtype;//>0
char data[10];
};
void main(int argc,char **argv)
{
int id;
	if(argc!=2)
	{
	printf("Usage: ./r mtype \n");
	printf("Ex: ./r 2\n");
	return;
	}
	id=msgget(5,IPC_CREAT|0664);

	if(id<0)
	{
	perror("msgget");
	return;
	}
printf("id=%d\n",id);
struct msgbuf v;

	msgrcv(id,&v,sizeof(v),atoi(argv[1]),0);
	printf("Data=%s\n",v.data);

}




