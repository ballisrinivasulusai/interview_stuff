#include"header.h"
struct msgbuf 
{
long mtype;//>0
char data[10];
};
void main(int argc,char **argv)
{
int id;
	if(argc!=3)
	{
	printf("Usage: ./t mtype msg\n");
	printf("Ex: ./t 2 Hello\n");
	return;
	}
	id=msgget(5,IPC_CREAT|0664);

	if(id<0)
	{
	perror("msgget");
	return;
	}
printf("id=%d\n",id);
struct msgbuf v;
v.mtype=atoi(argv[1]);
strcpy(v.data,argv[2]);
	msgsnd(id,&v,strlen(v.data)+1,0);
	perror("msgsnd");


}




