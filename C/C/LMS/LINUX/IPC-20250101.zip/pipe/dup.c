#include"header.h"
void main()
{
//int fd=dup(1);
int fd=dup2(1,9);

write(fd,"hello\n",6);



}
