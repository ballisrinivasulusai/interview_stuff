#include"header.h"
void main()
{
int a[5],i;
close(0);
int fd=open("abcd",O_RDONLY);
	if(fd<0)
	{
	perror("open");
	return;
	}
//printf("Hello World fd=%d\n",fd);

for(i=0;i<5;i++)
scanf("%d",&a[i]);

for(i=0;i<5;i++)
printf("%d ",a[i]);
printf("\n");

}
