#include"header.h"
void main()
{
int p[2];

pipe(p);
perror("pipe");
printf("p[0]=readend=%d\np[1]=writeend=%d\n",p[0],p[1]);

if(fork()==0)
{
char s[10];
printf("In c before read...\n");
read(p[0],s,sizeof(s));
printf("Data=%s\n",s);
}
else
{
char s[10];
printf("In p Enter the data...\n");
scanf("%s",s);
write(p[1],s,strlen(s)+1);
perror("write");

}


}
