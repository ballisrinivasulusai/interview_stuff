#include"header.h"
void main()
{
int a[5]={10,20,30,40,50},i;

int fd1=dup(1);
close(1);

int fd=open("abcd",O_WRONLY|O_TRUNC|O_CREAT,0664);
	if(fd<0)
	{
	perror("open");
	return;
	}
//printf("Hello World fd=%d\n",fd);

for(i=0;i<5;i++)
printf("%d ",a[i]);

write(fd1,"abcdefgh",8);
}
