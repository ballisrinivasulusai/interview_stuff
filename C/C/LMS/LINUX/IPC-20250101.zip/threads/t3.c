#include"header.h"
struct A
{
char f_name[10];
char ch;
};
void * thread_1(void *p)
{



}
void main(int argc,char **argv)
{
	if(argc!=3)
	{
	printf("Usage:./a.out fname char\n");
	return;
	}
struct A a1;
strcpy(a1.f_name,argv[1]);
a1.ch=argv[2][0];
	pthread_create(&t1,0,thread_1,&a1);

pthread_exit(0);

}

