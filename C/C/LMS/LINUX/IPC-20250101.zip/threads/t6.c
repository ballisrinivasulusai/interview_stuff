#include"header.h"

void * thread_1(void *p)
{

printf("In thread_1 %s\n",(char*)p);
sleep(20);
printf("In thread after sleep...\n");
pthread_exit("bye");
}

void main()
{
void *p;
pthread_t t1;
	pthread_create(&t1,0,thread_1,"Hello");

printf("In main thread before join...\n");
pthread_join(t1,&p);
printf("In main %s\n",(char *)p);

}
