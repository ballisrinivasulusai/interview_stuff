#include"header.h"
void * thread_1(void *p)
{
//	while(1)
	//printf("In thread pid=%d tid=%ld\n",getpid(),pthread_self());
	printf("In thread %s\n",(char *)p);
}
void main()
{
	pthread_t t1;

	pthread_create(&t1,0,thread_1,"Hai");
	printf("In main thread t1=%ld\n",t1);
	pthread_exit(0);

//	while(1);
//	printf("In main  thread pid=%d tid=%ld\n",getpid(),pthread_self()); 
}
