
void task1(void)
{

while(1)
printf("In task1...\n");

}
void task2(void)
{

while(1)
printf("In task2...\n");

}
void main()
{
if(fork()==0)
task1();
else
task2();
}
