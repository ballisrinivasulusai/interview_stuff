#include"header.h"
void my_isr(int n)
{
printf("In isr...\n");
sleep(30);
printf("In isr after sleep...\n");
}

void main()
{
printf("In main pid=%d\n",getpid());
printf("Hello...\n");
//signal(2,my_isr);
struct sigaction v;
v.sa_handler=my_isr;//SIG_DFL SIG_IGN
//sigemptyset(&v.sa_mask);
sigfillset(&v.sa_mask);
v.sa_flags=SA_NODEFER|SA_RESETHAND;

sigaction(2,&v,0);

printf("Hai...\n");
while(1);
}
