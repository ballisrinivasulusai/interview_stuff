#include"header.h"
void my_isr(int n)
{
printf("In isr pid=%d n=%d\n",getpid(),n);
}
void main()
{
if(fork()==0)
{
printf("In c pid=%d\n",getpid());
while(1);
}
else
{
printf("In p pid=%d\n",getpid());
//signal(SIGCHLD,my_isr);
struct sigaction v;

v.sa_handler=my_isr;
sigemptyset(&v.sa_mask);
v.sa_flags=SA_NOCLDSTOP|SA_NOCLDWAIT;

sigaction(SIGCHLD,&v,0);

while(1);
}

}
