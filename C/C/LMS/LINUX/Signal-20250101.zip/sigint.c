#include"header.h"
void my_isr(int n)
{
static int c=0;
printf("In isr pid=%d n=%d\n",getpid(),n);
c++;
if(c==3)
signal(n,SIG_DFL);

}
void main()
{
printf("In main pid=%d\n",getpid());
printf("Hello...\n");
signal(2,my_isr);
printf("Hai...\n");
while(1);
}
