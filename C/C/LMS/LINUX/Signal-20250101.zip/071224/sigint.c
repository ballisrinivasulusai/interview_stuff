#include"header.h"
void my_isr(int n)
{
static int c,c1;
if(n==2)
{
	c++;
		if(c==3)
		signal(n,SIG_DFL);

}
else if(n==3)
{
	c1++;
		if(c1==4)
		signal(n,SIG_DFL);
}
printf("In isr pid=%d n=%d\n",getpid(),n);

}
void main()
{
printf("In main pid=%d\n",getpid());
printf("Hello...\n");
signal(2,my_isr);
signal(3,my_isr);
printf("Hai...\n");
while(1);
}
