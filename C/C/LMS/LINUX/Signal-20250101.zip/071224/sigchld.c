#include"header.h"
void my_isr(int n)
{
printf("In isr pid=%d n=%d\n",getpid(),n);
wait(0);
}
void main()
{
if(fork()==0)
{
printf("In c pid=%d\n",getpid());
sleep(20);
printf("In c after sleep...\n");
}
else
{
printf("In p pid=%d\n",getpid());
signal(SIGCHLD,my_isr);
while(1);
}

}
