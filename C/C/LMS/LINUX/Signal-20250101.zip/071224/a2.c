#include"header.h"
int r;
void my_isr(int n)
{
r--;
printf("In isr...\n");
	if(r==0)
	raise(9);
	else
	alarm(r);

}
void main(int argc,char **argv)
{
printf("Hello pid=%d\n",getpid());
	if(argc!=2)
	{
	printf("Usage:./a.out num\n");
	return;
	}
r=atoi(argv[1]);	
signal(14,my_isr);
alarm(r);

while(1);

}
