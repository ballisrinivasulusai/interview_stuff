#include"header.h"
void my_isr(int n)
{
printf("In isr...\n");
sleep(20);
printf("In isr after 20 sec...\n");
}

void main()
{
printf("In main pid=%d\n",getpid());
printf("Hello...\n");
signal(2,my_isr);
printf("Hai...\n");
while(1);
}
