#include"header.h"
void main()
{

int r;
printf("Hello...\n");
r=alarm(10);
printf("1)r=%d\n",r);
sleep(3);
r=alarm(5);
printf("2) r=%d\n",r);
while(1);


}
