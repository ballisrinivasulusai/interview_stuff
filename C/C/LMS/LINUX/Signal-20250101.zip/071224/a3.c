#include"header.h"
void my_isr(int n)
{
printf("In isr...\n");
}
void main()
{
printf("Hello...\n");
signal(14,my_isr);
alarm(10);
sleep(20);
printf("Hai...\n");
while(1);
}
