#include"header.h"
void main()
{
FILE *fp=fopen("DATA","r");

	if(fp==0)
	{
		perror("fopen");
	}
	else
	{
	printf("File Present...\n");

	}



}
