#include"header.h"
void main()
{
printf("Hello World pid=%d\n",getpid());

while(1);
}
