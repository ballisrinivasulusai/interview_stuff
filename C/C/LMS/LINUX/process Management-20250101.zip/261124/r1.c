#include"header.h"
void main()
{
int a[5];
int i;
srand(getpid());
for(i=0;i<5;i++)
a[i]=rand()%101-50;//-50 to 50
//a[i]=rand()%51+50;//50-100
//a[i]=rand()%100+1;//1 to 100

for(i=0;i<5;i++)
printf("%d \n",a[i]);



}
