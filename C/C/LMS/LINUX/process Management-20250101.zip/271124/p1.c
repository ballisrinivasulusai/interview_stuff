#include"header.h"
void main()
{
printf("Hello World in p1.c pid=%d ppid=%d\n",getpid(),getppid());
sleep(30);
printf("in p1.c after sleep...\n");
}
