#include"header.h"
void main()
{
char s[20];
printf("Enter the string\n");
scanf("%s",s);
printf("s=%s\n",s);


}
