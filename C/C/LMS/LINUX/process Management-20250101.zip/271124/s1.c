#include"header.h"

void main()
{
printf("Hello...\n");
system("./p1");
printf("Hai...\n");



/*char s[10];
printf("Enter the cmd\n");
scanf("%s",s);
printf("Hello...\n");
system(s);
printf("Hai...\n");
*/
}
