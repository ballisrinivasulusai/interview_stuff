if(fork()==0)
{//y+1
	if(fork()==0)
	{//y+2
		if(fork()==0)
		{//y+3


		}
		else
		{//y+2


		}

	}
	else
	{//y+1

	}
	
}
else
{//y



}
