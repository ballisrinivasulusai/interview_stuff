#include"header.h"
void task1(void)
{
	while(1)
	printf("Task1...\n");
}
void task2(void)
{
	while(1)
	printf("\t\tTask2\n");
}
void main()
{
int r;
	r=fork();
	if(r==0)
	task1();
	else
	task2();
}
