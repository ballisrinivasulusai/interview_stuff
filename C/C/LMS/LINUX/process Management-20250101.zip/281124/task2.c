#include"header.h"

void main()
{
if(fork()==0)
system("ls");
else
system("pwd");
}
