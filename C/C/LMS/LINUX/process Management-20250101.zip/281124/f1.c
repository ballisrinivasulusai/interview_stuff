#include"header.h"
void main()
{
int r;
printf("Hello pid=%d\n",getpid());
r=fork();
if(r==0)
{
printf("In c ...\n");
}
else
{
printf("In P ...\n");
}
while(1);

}


