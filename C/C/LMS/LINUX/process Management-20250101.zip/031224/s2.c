#include"header.h"

void main()
{
printf("Hello...\n");
if(fork()==0)
system("ls");
else
system("pwd");
}
void main()
{
printf("Hello...\n");
if(fork()==0)
execl("/bin/ls","ls",NULL);
else
execl("/bin/pwd","pwd",NULL);
}










/*char s[10];
printf("Enter the cmd\n");
scanf("%s",s);
printf("Hello...\n");
system(s);
printf("Hai...\n");
*/

