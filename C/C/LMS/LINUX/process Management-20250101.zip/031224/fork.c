#include"header.h"
void main()
{
int i=10;

if(vfork()==0)
{
i=20;
printf("In c i=%d\n",i);
sleep(5);
exit(0);
}
else
{
//sleep(5);
printf("In p i=%d\n",i);



}





}
