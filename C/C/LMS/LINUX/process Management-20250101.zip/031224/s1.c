#include"header.h"

/*void main()
{
printf("Hello...\n");
system("ls");
printf("Hai...\n");
}*/


void main()
{
printf("Hello...\n");
//execl("/bin/ls","ls",NULL);
execlp("ls","ls","-l",NULL);
printf("Hai...\n");
}










/*char s[10];
printf("Enter the cmd\n");
scanf("%s",s);
printf("Hello...\n");
system(s);
printf("Hai...\n");
*/

