#include"header.h"
void main()
{

if(fork()==0)
{
printf("In c pid=%d ppid=%d\n",getpid(),getppid());
sleep(20);
printf("In c pid=%d ppid=%d\n",getpid(),getppid());
}
else
{
printf("In P pid=%d\n",getpid());
sleep(10);
printf("In p after sleep...\n");
}

}
