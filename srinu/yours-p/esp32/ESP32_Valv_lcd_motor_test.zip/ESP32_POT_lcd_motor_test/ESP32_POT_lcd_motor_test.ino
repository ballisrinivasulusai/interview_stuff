#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ==== LCD I2C Address ====
#define LCD_ADDR 0x27
LiquidCrystal_I2C lcd(LCD_ADDR, 16, 2);

// ==== I/O pins ====
#define MOTOR_PIN 2
#define IN1 12
#define IN2 13
#define IN3 14
#define IN4 27
#define PULSE_PIN 36

// ==== Output GPIOs ====
#define S_VALVE1 39
#define S_VALVE2 34
#define S_VALVE3 35
#define OUTPUT_VALVE 32

#define MOTOR_RUN_TIME 1000  // 1 second for demonstration
volatile bool buttonPressed = false;
volatile int buttonNum = 0;

// ==== LCD helper ====
void lcdPrintLine(uint8_t line, const String &text) {
  lcd.setCursor(0, line);
  lcd.print("                ");  // clear line
  lcd.setCursor(0, line);
  lcd.print(text);
}

// ==== Function to run 3-step valve sequence ====
void runValveSequence(int btnNum) {
  Serial.print("[BUTTON] Pressed: ");
  Serial.println(btnNum);

  // === Step 1 ===
  Serial.println("Step 1: S_VALVE1 HIGH, OUTPUT_VALVE HIGH, MOTOR ON");
  digitalWrite(S_VALVE1, HIGH);
  digitalWrite(OUTPUT_VALVE, HIGH);
  digitalWrite(MOTOR_PIN, HIGH);
  vTaskDelay(pdMS_TO_TICKS(MOTOR_RUN_TIME));
  digitalWrite(MOTOR_PIN, LOW);
  digitalWrite(S_VALVE1, LOW);
  digitalWrite(OUTPUT_VALVE, LOW);
  Serial.println("Step 1 complete, MOTOR OFF, VALVES LOW");
  vTaskDelay(pdMS_TO_TICKS(1000));

  // === Step 2 ===
  Serial.println("Step 2: S_VALVE2 HIGH, OUTPUT_VALVE HIGH, MOTOR ON");
  digitalWrite(S_VALVE2, HIGH);
  digitalWrite(OUTPUT_VALVE, HIGH);
  digitalWrite(MOTOR_PIN, HIGH);
  vTaskDelay(pdMS_TO_TICKS(MOTOR_RUN_TIME));
  digitalWrite(MOTOR_PIN, LOW);
  digitalWrite(S_VALVE2, LOW);
  digitalWrite(OUTPUT_VALVE, LOW);
  Serial.println("Step 2 complete, MOTOR OFF, VALVES LOW");
  vTaskDelay(pdMS_TO_TICKS(1000));

  // === Step 3 ===
  Serial.println("Step 3: S_VALVE3 HIGH, OUTPUT_VALVE HIGH, MOTOR ON");
  digitalWrite(S_VALVE3, HIGH);
  digitalWrite(OUTPUT_VALVE, HIGH);
  digitalWrite(MOTOR_PIN, HIGH);
  vTaskDelay(pdMS_TO_TICKS(MOTOR_RUN_TIME));
  digitalWrite(MOTOR_PIN, LOW);
  digitalWrite(S_VALVE3, LOW);
  digitalWrite(OUTPUT_VALVE, LOW);
  Serial.println("Step 3 complete, MOTOR OFF, VALVES LOW");

  Serial.println("Sequence completed\n");
}

// ======== TASK 1: Button & Motor Control ========
void taskButtonMotor(void *parameter) {
  for (;;) {
    bool in1 = (digitalRead(IN1) == LOW);
    bool in2 = (digitalRead(IN2) == LOW);
    bool in3 = (digitalRead(IN3) == LOW);
    bool in4 = (digitalRead(IN4) == LOW);

    if (in1 || in2 || in3 || in4) {
      buttonPressed = true;

      if (in1) buttonNum = 1;
      else if (in2) buttonNum = 2;
      else if (in3) buttonNum = 3;
      else if (in4) buttonNum = 4;

      // === Run the 3-step sequence ===
      runValveSequence(buttonNum);

      buttonPressed = false;
      buttonNum = 0;
    }

    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

// ======== TASK 2: LCD Display ========
void taskLCD(void *parameter) {
  static String lastLine1 = "";
  static String lastLine2 = "";

  for (;;) {
    String msg1, msg2;

    if (buttonPressed)
      msg1 = "Button " + String(buttonNum) + " Pressed";
    else
      msg1 = "No Button Press";

    msg2 = "Motor: ";
    msg2 += (buttonPressed ? "ON " : "OFF");

    if (msg1 != lastLine1) {
      lcdPrintLine(0, msg1);
      lastLine1 = msg1;
    }
    if (msg2 != lastLine2) {
      lcdPrintLine(1, msg2);
      lastLine2 = msg2;
    }

    vTaskDelay(150 / portTICK_PERIOD_MS);
  }
}

// ======== TASK 3: Pulse Monitor (Silent) ========
void taskPulseMonitor(void *pvParameters) {
  pinMode(PULSE_PIN, INPUT);

  while (1) {
    int pulseValue = analogRead(PULSE_PIN);
    // No LCD or Serial output
    vTaskDelay(pdMS_TO_TICKS(100));
  }
}

// ======== SCROLL MESSAGE ========
void scrollMessage(const String &line1, const String &line2) {
  int maxLen = max((int)line1.length(), (int)line2.length());

  for (int pos = 0; pos <= maxLen; pos++) {
    lcd.clear();

    int start1 = max(0, (int)line1.length() - 16);
    int start2 = max(0, (int)line2.length() - 16);

    if (pos < (int)line1.length())
      lcd.setCursor(0, 0), lcd.print(line1.substring(pos, pos + 16));
    else
      lcd.setCursor(0, 0), lcd.print(line1.substring(start1));

    if (pos < (int)line2.length())
      lcd.setCursor(0, 1), lcd.print(line2.substring(pos, pos + 16));
    else
      lcd.setCursor(0, 1), lcd.print(line2.substring(start2));

    delay(300);
  }
}

// ======== SETUP ========
void setup() {
  Serial.begin(115200);
  Serial.println("System Init with Full Scroll");

  // === Output Pins ===
  pinMode(MOTOR_PIN, OUTPUT);
  pinMode(S_VALVE1, OUTPUT);
  pinMode(S_VALVE2, OUTPUT);
  pinMode(S_VALVE3, OUTPUT);
  pinMode(OUTPUT_VALVE, OUTPUT);

  digitalWrite(MOTOR_PIN, LOW);
  digitalWrite(S_VALVE1, LOW);
  digitalWrite(S_VALVE2, LOW);
  digitalWrite(S_VALVE3, LOW);
  digitalWrite(OUTPUT_VALVE, LOW);

  // === Input Pins ===
  pinMode(IN1, INPUT_PULLUP);
  pinMode(IN2, INPUT_PULLUP);
  pinMode(IN3, INPUT_PULLUP);
  pinMode(IN4, INPUT_PULLUP);

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();

  // === Intro scroll ===
  scrollMessage("Liquid mix machine", "Waiting for user input");
  delay(1000);
  lcd.clear();

  // === Start tasks ===
  xTaskCreatePinnedToCore(taskButtonMotor, "ButtonMotorTask", 4096, NULL, 2, NULL, 1);
  xTaskCreatePinnedToCore(taskLCD, "LCDTask", 4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(taskPulseMonitor, "PulseMonitorTask", 2048, NULL, 1, NULL, 0);
}

void loop() {
  vTaskDelay(1000 / portTICK_PERIOD_MS);
}
